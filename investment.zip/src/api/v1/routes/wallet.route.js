const express = require('express');
const router = express.Router();
const { validateWallet } = require("../validations/wallet.validation")

//----------task------------------------------------------------------------------
const walletController = require('../controllers/wallet.controller');
router.post('/getBalance', validateWallet('getBalance'), walletController.getWalletBalance);
router.post('/addBalance', validateWallet('updateWalletBalance'), walletController.updateWalletBalance);
router.post('/reward',validateWallet('updateRewardWallet'), walletController.updateRewardWallet);
   

module.exports = router;