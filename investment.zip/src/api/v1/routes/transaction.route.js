const express = require('express');
const router = express.Router();
// const { validateRegister  , validateLogin} = require("../validations/user.validation")

//----------task------------------------------------------------------------------
// const taskController = require('../controllers/order/task.controller');
// router.post('/task/create', validateTask('createTask'), taskController.createTask);
   

module.exports = router;