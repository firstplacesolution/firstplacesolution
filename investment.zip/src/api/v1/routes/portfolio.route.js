const express = require('express');
const router = express.Router();
const { validatePortfolio} = require("../validations/portfolio.validation")

//----------task------------------------------------------------------------------
const portfolioController = require('../controllers/portfolio.controller');

router.post('/add', validatePortfolio('potfolio'),portfolioController.portfolio);   
router.post('/data',validatePortfolio('getAll'),portfolioController.getAll)

module.exports = router;