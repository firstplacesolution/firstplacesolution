const portfolioModel = require("../models/portfolio.models");

async function checkPortfolioByUserId(user_id) {
    const portfolioDetails = await portfolioModel.findOne({ user_id });
    return portfolioDetails ? true : false;
}

async function checkPortfolioBylocking(lockin) {
    const portfolioDetails = await portfolioModel.findOne({ lockin : lockin });
    return portfolioDetails ? true : false;
}

async function getPortfolioDetailsByInvestorId(investor_id) {
    const portfolioDetails = await portfolioModel.find({ investor_id });
    return portfolioDetails ? portfolioDetails : "notFound";
}

async function getPortfolioDetailsBylocking(lockin) {
    const portfolioDetails = await portfolioModel.findOne({ lockin : lockin });
    return portfolioDetails ? portfolioDetails : "notFound";
}


module.exports = {
    checkPortfolioByUserId,
    checkPortfolioBylocking,
    getPortfolioDetailsByInvestorId,
    getPortfolioDetailsBylocking
}