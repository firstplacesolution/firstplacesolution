const express = require('express');
const router = express.Router();
const nodeCron = require("node-cron");
const {investorID} =require('./helpers/reward.helpers');
// investorID();
// let a = list
// console.log(a)
// function nikit() {
    
// }

const db=require("../v1/config/mongodb");
let a = investorID().then((result)=>{
    console.log(result);
})

// nodeCron.schedule("* * * * * *",InvestorID);


const userRoute = require('../v1/routes/user.route');
const investorRoute = require('../v1/routes/investor.route');
const kycRoute = require('../v1/routes/kyc.route');
const transactionRoute = require('../v1/routes/transaction.route');
const walletRoute = require('../v1/routes/wallet.route');
const locationRoute = require('../v1/routes/location.route');
const portfolioRoute = require('../v1/routes/portfolio.route');

router.use('/user', userRoute);
router.use('/investor', investorRoute);
router.use('/kyc', kycRoute);
router.use('/transaction', transactionRoute);
router.use('/wallet', walletRoute);
router.use('/location', locationRoute);
router.use('/portfolio', portfolioRoute);

module.exports = router;