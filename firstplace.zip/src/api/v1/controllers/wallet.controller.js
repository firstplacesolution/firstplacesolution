const { success, unknownError, serverValidation, badRequest } = require('../helpers/response.helper');
const { validationResult } = require('express-validator');
const walletModel = require("../models/wallet.model");
const { getInvestorWalletByInvestorId } = require("../helpers/wallet.helper");
const {getPortfolioDetailsByInvestorId} = require('../helpers/portfolio.helper')
const {getALLInvestorID} = require('../helpers/investor.helper')


module.exports = {

    getWalletBalance: async (req, res) => {
        try {
            const errors = validationResult(req);
            if (!errors.isEmpty()) {
                serverValidation(res, { errorName: "serverValidation", errors: errors.array() })
            } else {
                const investorWallet = await getInvestorWalletByInvestorId(req.params.investor_id);
                if (investorWallet == "notFound") {
                    badRequest(res, "Investor Wallet not Found");
                } else {
                    success(res, "Investor Wallet", investorWallet)
                }
            }
        } catch (error) {
            console.log(error);
            unknownError(res, error);
        }
    },

    updateWalletBalance: async (req, res) => {
        try {
            const errors = validationResult(req);
            if (!errors.isEmpty()) {
                serverValidation(res, { errorName: "serverValidation", errors: errors.array() })
            } else {
                const { investor_id, amount } = req.body;
                const investorWallet = await getInvestorWalletByInvestorId(req.body.investor_id);
                if (investorWallet == "notFound") {
                    badRequest(res, "Investor Wallet not Found");
                } else {
                    const newBaseWalletBalance = parseInt(investorWallet.base_wallet) + parseInt(amount);
                    const walletBalanceUpdate = await walletModel.findOneAndUpdate({ investor_id }, { base_wallet: newBaseWalletBalance });
                    if (walletBalanceUpdate) {
                        success(res, 'Balance Updated Successfully');
                    } else {
                        badRequest(res, 'Invalid Details')
                    }
                }

            }
        } catch (error) {
            console.log(error)
            unknownError(res, error);
        }
    },
InvestorID: () => {
        let investmentIdList=[];

        getALLInvestorID().then((data)=>{
            // console.log(data);


            investmentIdList = data.map(function(element){
    return element.id;
});
// console.log("investmentIdList==========="+JSON.stringify(investmentIdList));
        investmentIdList.forEach(element => {
                const investorWalletData= getInvestorWalletByInvestorId(element).then((wallet)=>{
                    // console.log(wallet);
                    const investorPortfolioData = getPortfolioDetailsByInvestorId(element).then((result)=>{
                        const sumOfPortfolioAmount = result.map(item => item.amount).reduce((prev, curr) => prev + curr, 0);
                        // console.log("SUM AMOUNT OF INVESTOR PORTFOLIO +++++++++++++++++++"+ sumOfPortfolioAmount);
                        let rewardYearly = parseFloat(sumOfPortfolioAmount*process.env.PORTFOLIO_RATE/100/12/30);
                        // console.log("=======================Reward Yearly================",rewardYearly);
                        const newBaseWalletBalance = parseFloat(wallet.reward_wallet) + parseFloat(rewardYearly);
                        console.log(investmentIdList)
                        walletModel.findOneAndUpdate(element, {reward_wallet: newBaseWalletBalance },(err,doc)=>{
                            console.log(doc)
                        })
                        //    console.log(newBaseWalletBalance)
                        
                    })
                        // .then((invertmentWallet)=>{
                        //    .then(function (list) {
                        //         list.forEach(block => {
                    //             investedAmount += block.amount
                    //         });
                //         let rewardYearly = parseFloat(investedAmount*process.env.PORTFOLIO_RATE/100/12/30) 
                //         const newBaseWalletBalance = parseFloat(invertmentWallet.reward_wallet) + parseFloat(rewardYearly);
                //         console.log(invertmentWallet.reward_wallet,newBaseWalletBalance,element)

                //         if(err){
                //             console.log("ERR",err);

                //         }
                //         console.log(doc);                        });
                //     })
                //         })
                    });
                })
                });
            }
        }
            